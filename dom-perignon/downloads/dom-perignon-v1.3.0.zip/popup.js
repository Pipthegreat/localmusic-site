// DOM Pérignon popup - hijink picker
//
// State lives in chrome.storage.local:
//   activeHack:  which hijink the radio list has selected
//   enabled:     master Active toggle (on/off)
//   easterEgg:   hidden ">_" override - applies the original ui-updater-2
//                themes on claude.ai + chatgpt.com, bypassing everything else
//
// On any change, broadcast a 'reactivate' message to every tab so inject.js
// re-reads the full storage state and picks the right theme via pickTheme().

const HACKS = [
  { id: 'ants',          name: 'Ants',                desc: 'A colony marches across the page', popular: true },
  { id: 'champagne',     name: 'Champagne Bubbles',   desc: 'Bubbles rise, corks pop, the page fizzes', signature: true },
  { id: 'dynamic-logo',  name: 'Logo Bounce House',   desc: "The site's logo, loose and bouncing" },
  { id: 'quotes',        name: 'You Got This',        desc: 'A little laid-back inspiration' },
  { id: 'gravity-well',  name: 'Gravity Well',        desc: 'Page elements slowly fall and pile at the bottom, click to rescue' },
  { id: 'aquarium',      name: 'Aquarium',            desc: 'The page becomes the back wall of a tank' },
  { id: 'googly',        name: 'Watchers',            desc: 'Eyes appear, they follow your cursor, they do not blink' },
  { id: 'dvd',           name: 'DVD Bouncer',         desc: "If you're feeling nostalgic and uninspired" },
];

const toggle     = document.getElementById('enabledToggle');
const listEl     = document.getElementById('hackList');
const easterEgg  = document.getElementById('easterEggToggle');

// Render the radio list. Inline badge sits to the right of the name (saves
// the row of vertical space the old "badge below desc" layout used).
function renderList(activeHack, enabled) {
  listEl.innerHTML = HACKS.map(h => {
    let badge = '';
    if (h.signature)   badge = '<span class="badge badge-signature">House signature</span>';
    else if (h.popular) badge = '<span class="badge badge-popular">Most popular</span>';
    return `
    <li>
      <label class="hack" data-id="${h.id}">
        <input type="radio" name="hack" value="${h.id}" ${h.id === activeHack ? 'checked' : ''} ${!enabled ? 'disabled' : ''}>
        <span class="radio"></span>
        <span class="meta">
          <div class="name-row">
            <span class="name">${h.name}</span>
            ${badge}
          </div>
          <div class="desc">${h.desc}</div>
        </span>
      </label>
    </li>
    `;
  }).join('');

  // Dim the list visually when the master toggle is off
  listEl.style.opacity = enabled ? '1' : '0.35';
  listEl.style.pointerEvents = enabled ? 'auto' : 'none';

  // Wire each radio: save selection + ask every tab to re-evaluate
  listEl.querySelectorAll('input[type=radio]').forEach(input => {
    input.addEventListener('change', async () => {
      await chrome.storage.local.set({ activeHack: input.value });
      await broadcastReactivate();
      // Re-render so the active-radio styling moves
      const { enabled: e } = await chrome.storage.local.get({ enabled: true });
      renderList(input.value, e);
    });
  });
}

// Tell every tab to re-read storage and apply pickTheme()
async function broadcastReactivate() {
  try {
    const tabs = await chrome.tabs.query({});
    for (const tab of tabs) {
      if (!tab.id) continue;
      try {
        await chrome.tabs.sendMessage(tab.id, { type: 'reactivate' });
      } catch { /* tab without our content script (chrome://, web store, etc.) */ }
    }
  } catch { /* tabs API unavailable */ }
}

// Master Active toggle
toggle.addEventListener('change', async () => {
  await chrome.storage.local.set({ enabled: toggle.checked });
  await broadcastReactivate();
  const { activeHack } = await chrome.storage.local.get({ activeHack: 'off' });
  renderList(activeHack, toggle.checked);
});

// Easter-egg ">_" toggle - flips the easterEgg state in storage and updates
// the icon's visual (dim phosphor when off, glowing when on). Broadcasts so
// every tab re-evaluates; on claude.ai + chatgpt.com the override takes
// effect, everywhere else nothing visible changes.
easterEgg.addEventListener('click', async () => {
  const { easterEgg: current } = await chrome.storage.local.get({ easterEgg: false });
  const newState = !current;
  await chrome.storage.local.set({ easterEgg: newState });
  if (newState) easterEgg.classList.add('active');
  else easterEgg.classList.remove('active');
  await broadcastReactivate();
});

// Initial hydrate from storage
(async () => {
  const { activeHack, enabled, easterEgg: ezr } = await chrome.storage.local.get({
    activeHack: 'off',
    enabled:    true,
    easterEgg:  false,
  });
  toggle.checked = enabled;
  if (ezr) easterEgg.classList.add('active');
  renderList(activeHack, enabled);
})();
