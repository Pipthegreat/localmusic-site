// DOM Pérignon popup - hijink picker + dual ">_" overrides.
//
// State lives in chrome.storage.local:
//   activeHack:  which hijink the radio list has selected
//   enabled:     master Active toggle (on/off)
//   greenMode:   green ">_" override - applies matrix-green everywhere,
//                or the full ezr-claude theme on claude.ai
//   redMode:     red ">_" override - applies matrix-red everywhere,
//                or the full ezr-chatgpt theme on chatgpt.com
//
// Mutual exclusion: activating either ">_" toggle deactivates the
// other AND turns off the master Active switch. The master Active
// switch staying off is intentional (visual cue that the regular
// hijinks aren't running while a ">_" override is active).
//
// On any change, broadcast a 'reactivate' message to every tab so
// inject.js re-reads full storage state and picks the right theme
// via pickTheme().

const HACKS = [
  { id: 'ants',          name: 'Ants',                desc: 'A colony marches across the page', popular: true },
  { id: 'champagne',     name: 'Champagne Bubbles',   desc: 'Bubbles rise, corks pop, the page fizzes', signature: true },
  { id: 'dynamic-logo',  name: 'Logo Bounce House',   desc: "The site's logo, loose and bouncing" },
  { id: 'quotes',        name: 'You Got This',        desc: 'A little laid-back inspiration' },
  { id: 'gravity-well',  name: 'Gravity Well',        desc: 'Page elements slowly fall and pile at the bottom, click to rescue' },
  { id: 'aquarium',      name: 'Aquarium',            desc: 'The page becomes the back wall of a tank' },
  { id: 'googly',        name: 'Watchers',            desc: "I wanna feel like somebody's watchin' me" },
  { id: 'dvd',           name: 'DVD Bouncer',         desc: "If you're feeling nostalgic and uninspired" },
];

const toggle        = document.getElementById('enabledToggle');
const listEl        = document.getElementById('hackList');
const greenEgg      = document.getElementById('greenEggToggle');
const redEgg        = document.getElementById('redEggToggle');
const easterTooltip = document.getElementById('easterEggTooltip');
let easterTooltipTimer = null;

// Render the radio list. Inline badge sits to the right of the name.
function renderList(activeHack, enabled) {
  listEl.innerHTML = HACKS.map(h => {
    let badge = '';
    if (h.signature)   badge = '<span class="badge badge-signature">House signature</span>';
    else if (h.popular) badge = '<span class="badge badge-popular">Most popular</span>';
    return `
    <li>
      <label class="hack" data-id="${h.id}">
        <input type="radio" name="hack" value="${h.id}" ${h.id === activeHack ? 'checked' : ''} ${!enabled ? 'disabled' : ''}>
        <span class="radio"></span>
        <span class="meta">
          <div class="name-row">
            <span class="name">${h.name}</span>
            ${badge}
          </div>
          <div class="desc">${h.desc}</div>
        </span>
      </label>
    </li>
    `;
  }).join('');

  // Dim the list visually when the master toggle is off
  listEl.style.opacity = enabled ? '1' : '0.35';
  listEl.style.pointerEvents = enabled ? 'auto' : 'none';

  // Wire each radio: save selection + ask every tab to re-evaluate
  listEl.querySelectorAll('input[type=radio]').forEach(input => {
    input.addEventListener('change', async () => {
      await chrome.storage.local.set({ activeHack: input.value });
      await broadcastReactivate();
      // Re-render so the active-radio styling moves
      const { enabled: e } = await chrome.storage.local.get({ enabled: true });
      renderList(input.value, e);
    });
  });
}

// Tell every tab to re-read storage and apply pickTheme()
async function broadcastReactivate() {
  try {
    const tabs = await chrome.tabs.query({});
    for (const tab of tabs) {
      if (!tab.id) continue;
      try {
        await chrome.tabs.sendMessage(tab.id, { type: 'reactivate' });
      } catch { /* tab without our content script (chrome://, web store, etc.) */ }
    }
  } catch { /* tabs API unavailable */ }
}

// Flash the scope-tooltip near the buttons. ~750ms hold + 100ms fade
// for a total visible cycle of ~850ms (the tighter, snappier window
// from v1.3.7). Only fires on activation, never on deactivation.
function flashTooltip(text, red) {
  easterTooltip.textContent = text;
  easterTooltip.classList.toggle('red', !!red);
  easterTooltip.classList.add('visible');
  clearTimeout(easterTooltipTimer);
  easterTooltipTimer = setTimeout(() => {
    easterTooltip.classList.remove('visible');
  }, 750);
}

// Master Active toggle
toggle.addEventListener('change', async () => {
  await chrome.storage.local.set({ enabled: toggle.checked });
  await broadcastReactivate();
  const { activeHack } = await chrome.storage.local.get({ activeHack: 'off' });
  renderList(activeHack, toggle.checked);
});

// Green ">_" — activating turns off red + master Active.
greenEgg.addEventListener('click', async () => {
  const { greenMode: current } = await chrome.storage.local.get({ greenMode: false });
  const newState = !current;

  const updates = { greenMode: newState };
  if (newState) {
    updates.redMode = false;
    updates.enabled = false;
  }
  await chrome.storage.local.set(updates);

  greenEgg.classList.toggle('active', newState);
  if (newState) {
    redEgg.classList.remove('active');
    toggle.checked = false;
    const { activeHack } = await chrome.storage.local.get({ activeHack: 'off' });
    renderList(activeHack, false);
    flashTooltip('best on claude.ai', false);
  }
  await broadcastReactivate();
});

// Red ">_" — symmetric counterpart. Activating turns off green +
// master Active. Tooltip switches to red palette + chatgpt scope.
redEgg.addEventListener('click', async () => {
  const { redMode: current } = await chrome.storage.local.get({ redMode: false });
  const newState = !current;

  const updates = { redMode: newState };
  if (newState) {
    updates.greenMode = false;
    updates.enabled   = false;
  }
  await chrome.storage.local.set(updates);

  redEgg.classList.toggle('active', newState);
  if (newState) {
    greenEgg.classList.remove('active');
    toggle.checked = false;
    const { activeHack } = await chrome.storage.local.get({ activeHack: 'off' });
    renderList(activeHack, false);
    flashTooltip('best on chatgpt.com', true);
  }
  await broadcastReactivate();
});

// Initial hydrate from storage
(async () => {
  const { activeHack, enabled, greenMode, redMode } = await chrome.storage.local.get({
    activeHack: 'off',
    enabled:    true,
    greenMode:  false,
    redMode:    false,
  });
  toggle.checked = enabled;
  if (greenMode) greenEgg.classList.add('active');
  if (redMode)   redEgg.classList.add('active');
  renderList(activeHack, enabled);
})();
