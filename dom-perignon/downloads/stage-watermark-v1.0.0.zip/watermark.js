// Stage Watermark - content script
//
// URL gate: both 'adobe' and 'stage' must appear in the hostname (the
// part before the '.com' TLD). Anything else: exit silently. On any
// matching page, build 7 watermark elements that float behind the
// content with X+Y bouncing animations (see watermark.css).

(function () {
  const host = (window.location.hostname || '').toLowerCase();

  // Hostname must end in '.com' AND contain both 'adobe' and 'stage'
  // somewhere before the .com TLD. The .indexOf check on the base
  // (hostname without the trailing '.com') keeps us off shopping
  // pages like 'adobeshop.com.example.org' that incidentally match.
  if (!host.endsWith('.com')) return;
  const base = host.slice(0, -4);
  if (!base.includes('adobe') || !base.includes('stage')) return;

  const CONTAINER_ID = '__stage-watermark';
  const CSS_LINK_ID  = '__stage-watermark-css';
  const COUNT        = 7;

  function mount() {
    if (document.getElementById(CONTAINER_ID)) return;

    // Inject stylesheet
    if (!document.getElementById(CSS_LINK_ID)) {
      const link = document.createElement('link');
      link.id   = CSS_LINK_ID;
      link.rel  = 'stylesheet';
      link.href = chrome.runtime.getURL('watermark.css');
      (document.head || document.documentElement).appendChild(link);
    }

    // Container + 7 watermarks. Each watermark has an outer (X-bounce)
    // and inner (Y-bounce + flex row for glyph + 'Stage' text).
    const container = document.createElement('div');
    container.id = CONTAINER_ID;
    container.className = 'sw-bounce';
    for (let i = 0; i < COUNT; i++) {
      const w = document.createElement('div');
      w.className = `sw-watermark sw-logo-${i}`;
      const inner = document.createElement('div');
      inner.className = 'sw-inner';
      const glyph = document.createElement('span');
      glyph.className = 'sw-glyph';
      const text = document.createElement('span');
      text.className = 'sw-text';
      text.textContent = 'Stage';
      inner.appendChild(glyph);
      inner.appendChild(text);
      w.appendChild(inner);
      container.appendChild(w);
    }

    (document.body || document.documentElement).appendChild(container);
  }

  function unmount() {
    document.getElementById(CONTAINER_ID)?.remove();
    document.getElementById(CSS_LINK_ID)?.remove();
  }

  // Initial state from storage (default ON)
  chrome.storage.local.get({ enabled: true }, ({ enabled }) => {
    if (enabled) mount();
  });

  // Live toggle from popup
  chrome.runtime.onMessage.addListener((msg) => {
    if (!msg || msg.type !== 'toggle') return;
    if (msg.enabled) mount();
    else unmount();
  });
})();
