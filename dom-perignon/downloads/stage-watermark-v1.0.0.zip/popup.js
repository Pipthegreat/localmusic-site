// Stage Watermark - popup
//
// One state key: chrome.storage.local.enabled. On change, broadcast a
// 'toggle' message to every tab so any matching page mounts/unmounts
// the watermark without a reload.

const toggle = document.getElementById('enabledToggle');

async function broadcastToggle(enabled) {
  try {
    const tabs = await chrome.tabs.query({});
    for (const tab of tabs) {
      if (!tab.id) continue;
      try {
        await chrome.tabs.sendMessage(tab.id, { type: 'toggle', enabled });
      } catch { /* tab without our content script - chrome://, etc. */ }
    }
  } catch { /* tabs API unavailable */ }
}

toggle.addEventListener('change', async () => {
  await chrome.storage.local.set({ enabled: toggle.checked });
  await broadcastToggle(toggle.checked);
});

// Hydrate from storage (default ON)
(async () => {
  const { enabled } = await chrome.storage.local.get({ enabled: true });
  toggle.checked = enabled;
})();
