// DOM Pérignon popup — dual-slot picker + ">_" overrides.
//
// State in chrome.storage.local:
//   activeOverlay : string|null — which overlay is on (ants, champagne, …)
//   activeTheme   : string|null — which theme world is on (tubular, …)
//   enabled       : boolean      — master Active switch (gates both slots)
//   greenMode     : boolean      — green ">_" override
//   redMode       : boolean      — red ">_" override
//
// Layout: two columns. Overlays left, themes right. Each column is an
// independent radio group; one of each can be active at the same time.
// Clicking an already-selected pick deselects it — supports "just an
// overlay", "just a theme", "both", or "neither".
//
// The master Active toggle still gates everything. ">_" overrides still
// bypass Active and the regular slots (they occupy the theme slot only).
//
// Migration from v1.4.x–v1.5.2 (single activeHack key) is handled in
// inject.js on first read.

const HACKS = [
  // ───── Overlays — live DOM animations on top of the page ─────
  { id: 'ants',          name: 'Ants',                desc: 'A colony marches across the page', kind: 'overlay', popular: true },
  { id: 'champagne',     name: 'Champagne Bubbles',   desc: 'Bubbles rise, corks pop, the page fizzes', kind: 'overlay', signature: true },
  { id: 'dynamic-logo',  name: 'Logo Bounce House',   desc: "The site's logo, loose and bouncing", kind: 'overlay' },
  { id: 'quotes',        name: 'You Got This',        desc: 'A little laid-back inspiration', kind: 'overlay' },
  { id: 'gravity-well',  name: 'Gravity Well',        desc: 'Page elements fall and pile, click to rescue', kind: 'overlay' },
  { id: 'aquarium',      name: 'Aquarium',            desc: 'The page becomes the back wall of a tank', kind: 'overlay' },
  { id: 'googly',        name: 'Watchers',            desc: "I wanna feel like somebody's watchin' me", kind: 'overlay' },
  { id: 'dvd',           name: 'DVD Bouncer',         desc: "If you're feeling nostalgic and uninspired", kind: 'overlay' },

  // ───── Theme worlds — whole-page graphic overrides (CSS only) ─────
  { id: 'tubular',       name: 'Tubular',             desc: 'Glitch noir — oxblood and persimmon, scanlines', kind: 'theme' },
  { id: 'arcade',        name: 'Arcade',              desc: '1985 cabinet — neon CRT, Press Start 2P', kind: 'theme' },
  { id: 'buzzbin',       name: 'Buzzbin',             desc: "MTV '92 sticker bomb — halftone, magenta + cyan", kind: 'theme' },
  { id: 'vapor',         name: 'Vaporwave',           desc: '¥€$ — pastel grid horizon, DM Serif Display', kind: 'theme' },
  { id: 'press',         name: 'Press',               desc: 'Brutalist newsprint — black on cream + red', kind: 'theme' },
  { id: 'blueprint',     name: 'Blueprint',           desc: "Drafting — cyan on navy, Architects Daughter", kind: 'theme' },
  { id: 'chalkboard',    name: 'Chalkboard',          desc: 'Schoolroom slate — chalk Caveat, wood rail', kind: 'theme' },
];

const OVERLAYS = HACKS.filter(h => h.kind === 'overlay');
const THEMES   = HACKS.filter(h => h.kind === 'theme');

const toggle        = document.getElementById('enabledToggle');
const listEl        = document.getElementById('hackList');
const greenEgg      = document.getElementById('greenEggToggle');
const redEgg        = document.getElementById('redEggToggle');
const easterTooltip = document.getElementById('easterEggTooltip');
let easterTooltipTimer = null;

function cellHtml(h, isActive /*, enabled */) {
  let badge = '';
  if (h.signature)    badge = '<span class="badge badge-signature">House signature</span>';
  else if (h.popular) badge = '<span class="badge badge-popular">Most popular</span>';
  // Each column gets its own radio group name so the two picks don't
  // exclude each other. The `disabled` attribute is intentionally NEVER
  // set anymore — even when Active is off, the tiles need to remain
  // clickable so a single click can wake Active + select the tile in
  // one motion. The dim "off" look is now applied via .hack-list-off
  // on the list container, not by disabling inputs.
  return `
    <label class="hack" data-id="${h.id}" data-kind="${h.kind}">
      <input type="radio" name="hack-${h.kind}" data-kind="${h.kind}" value="${h.id}" ${isActive ? 'checked' : ''}>
      <span class="radio"></span>
      <span class="meta">
        <div class="name-row">
          <span class="name">${h.name}</span>
          ${badge}
        </div>
        <div class="desc">${h.desc}</div>
      </span>
    </label>
  `;
}

// Two-column render. Rows pair OVERLAYS[i] with THEMES[i]; trailing
// unpaired entries get an empty placeholder cell so the grid stays
// aligned. Each cell is wired with a click handler that supports
// click-to-deselect (clicking a checked radio clears it).
function renderList(activeOverlay, activeTheme, enabled) {
  const rowCount = Math.max(OVERLAYS.length, THEMES.length);
  const rows = [];
  rows.push(`
    <div class="pair-headers">
      <div>Overlays</div>
      <div>Theme worlds</div>
    </div>
  `);
  for (let i = 0; i < rowCount; i++) {
    const o = OVERLAYS[i];
    const t = THEMES[i];
    rows.push(`
      <div class="pair-row">
        ${o ? cellHtml(o, activeOverlay === o.id, enabled) : '<div class="cell-empty"></div>'}
        ${t ? cellHtml(t, activeTheme   === t.id, enabled) : '<div class="cell-empty"></div>'}
      </div>
    `);
  }
  listEl.innerHTML = rows.join('');

  // Visual dim when Active is off — but tiles stay clickable. A single
  // click on any tile will wake Active and select that tile (see the
  // click handler below).
  listEl.style.opacity = enabled ? '1' : '0.55';
  listEl.style.pointerEvents = 'auto';
  listEl.classList.toggle('hack-list-off', !enabled);

  // Click-to-deselect when Active is on. When Active is OFF, the same
  // click wakes Active AND selects the clicked tile in one motion —
  // users coming back to the popup don't have to flip the toggle first.
  listEl.querySelectorAll('label.hack').forEach(label => {
    label.addEventListener('click', async (e) => {
      e.preventDefault();
      const input = label.querySelector('input[type=radio]');
      if (!input) return;
      const kind = input.dataset.kind;
      const id   = input.value;

      // Read storage right before deciding so we use the actual current
      // state, not whatever was captured when this row was rendered.
      const state = await chrome.storage.local.get({
        activeOverlay: null, activeTheme: null, enabled: true,
        greenMode: false, redMode: false,
      });

      // ">_" overrides own the theme slot while they're on. Don't fight
      // them — clicking a tile while ">_" is active is a no-op.
      if (state.greenMode || state.redMode) return;

      const updates = {};
      if (!state.enabled) {
        // Wake Active AND select the tile in one click.
        updates.enabled = true;
        if (kind === 'overlay') updates.activeOverlay = id;
        else                    updates.activeTheme   = id;
      } else {
        // Normal click-to-deselect within the slot.
        const wasChecked = (kind === 'overlay')
          ? (state.activeOverlay === id)
          : (state.activeTheme   === id);
        if (kind === 'overlay') updates.activeOverlay = wasChecked ? null : id;
        else                    updates.activeTheme   = wasChecked ? null : id;
      }

      await chrome.storage.local.set(updates);
      // syncActiveToSelection handles the "deselecting the last pick →
      // Active off" branch; it's a no-op when we just woke Active.
      await syncActiveToSelection();
      await broadcastReactivate();
      await renderFromStorage();
    });
  });
}

// Keep the master Active toggle in sync with whether the user actually
// has any selection. Logic:
//   - both slots empty → Active off (nothing for the toggle to gate)
//   - at least one slot filled → Active on (the pick takes effect)
// The ">_" overrides own the enabled flag while they're on (they force
// it off as part of mutual exclusion with regular picks). When a ">_"
// is active this helper steps aside so we don't fight the override.
async function syncActiveToSelection() {
  const state = await chrome.storage.local.get({
    activeOverlay: null, activeTheme: null, enabled: true,
    greenMode: false, redMode: false,
  });
  if (state.greenMode || state.redMode) return state;
  const hasAny = !!(state.activeOverlay || state.activeTheme);
  if (state.enabled !== hasAny) {
    await chrome.storage.local.set({ enabled: hasAny });
    state.enabled = hasAny;
  }
  return state;
}

// Single rendering surface — every handler ends by calling this so the
// UI is rebuilt from chrome.storage as it stands NOW, not from a local
// var captured earlier in the handler.
//
// Why this exists: when two handlers race (e.g. user clicks the Active
// toggle while a click-to-deselect is still in flight, or
// forceToggleOff dispatches a synthesized change event mid-handler),
// each handler captures its "enabled" flag at its own start. Whichever
// completes LAST overwrites the UI with its stale local var — toggle
// could end up checked while renderList was called with enabled=false,
// dimming the list and disabling pointer-events. Symptom: "Active is on
// but I can't select any bubbles."
//
// Reading storage at the end means the final UI always matches storage.
// Chrome serializes storage.local.set calls in arrival order, so the
// last write wins consistently — and reading right after broadcasts is
// the right moment to capture that final value.
async function renderFromStorage() {
  const state = await chrome.storage.local.get({
    activeOverlay: null, activeTheme: null,
    enabled: true, greenMode: false, redMode: false,
  });
  toggle.checked = state.enabled;
  greenEgg.classList.toggle('active', state.greenMode);
  redEgg.classList.toggle('active', state.redMode);
  renderList(state.activeOverlay, state.activeTheme, state.enabled);
  return state;
}

async function broadcastReactivate() {
  try {
    const tabs = await chrome.tabs.query({});
    for (const tab of tabs) {
      if (!tab.id) continue;
      try { await chrome.tabs.sendMessage(tab.id, { type: 'reactivate' }); }
      catch { /* tab without our content script (chrome://, web store, etc.) */ }
    }
  } catch { /* tabs API unavailable */ }
}

function flashTooltip(text, red) {
  easterTooltip.textContent = text;
  easterTooltip.classList.toggle('red', !!red);
  easterTooltip.classList.add('visible');
  clearTimeout(easterTooltipTimer);
  easterTooltipTimer = setTimeout(() => easterTooltip.classList.remove('visible'), 750);
}

// (Note: prior versions had a forceToggleOff() helper that synthesized
// a change event when the ">_" overrides forced Active off. That was a
// source of concurrent-handler races — the synthesized event triggered
// the toggle's change handler in parallel with the ">_" handler. Now
// renderFromStorage sets toggle.checked directly from the post-set
// storage value at the end of each handler, so the helper is gone.)

// Master Active toggle — gates BOTH the overlay slot and the theme slot.
// Flipping ON also clears any ">_" override (mutual exclusion preserved
// from v1.4.x).
toggle.addEventListener('change', async () => {
  const enabled = toggle.checked;
  const updates = { enabled };
  if (enabled) {
    updates.greenMode = false;
    updates.redMode   = false;
  }
  await chrome.storage.local.set(updates);
  await broadcastReactivate();
  // Render from storage (not from the local `enabled` captured at
  // handler start) so concurrent handlers can't desync the UI.
  await renderFromStorage();
});

greenEgg.addEventListener('click', async () => {
  const { greenMode: current } = await chrome.storage.local.get({ greenMode: false });
  const newState = !current;
  const updates = { greenMode: newState };
  if (newState) {
    updates.redMode = false;
    updates.enabled = false;
  }
  await chrome.storage.local.set(updates);
  if (newState) {
    flashTooltip('best on claude.ai', false);
  } else {
    // Turning the override OFF — restore Active to match the user's
    // saved picks. If they had something selected, it resumes; if not,
    // Active stays off.
    await syncActiveToSelection();
  }
  await broadcastReactivate();
  await renderFromStorage();
});

redEgg.addEventListener('click', async () => {
  const { redMode: current } = await chrome.storage.local.get({ redMode: false });
  const newState = !current;
  const updates = { redMode: newState };
  if (newState) {
    updates.greenMode = false;
    updates.enabled   = false;
  }
  await chrome.storage.local.set(updates);
  if (newState) {
    flashTooltip('best on chatgpt.com', true);
  } else {
    // Turning the override OFF — restore Active to match the user's
    // saved picks.
    await syncActiveToSelection();
  }
  await broadcastReactivate();
  await renderFromStorage();
});

// Initial hydrate. Lazy-migrate the legacy single-slot activeHack key
// the first time the popup opens after upgrading to v1.5.3.
(async () => {
  const stored = await chrome.storage.local.get({
    activeHack:    null,
    activeOverlay: null,
    activeTheme:   null,
    enabled:       true,
    greenMode:     false,
    redMode:       false,
  });

  if (stored.activeHack && !stored.activeOverlay && !stored.activeTheme) {
    const overlayIds = new Set(OVERLAYS.map(h => h.id));
    const themeIds   = new Set(THEMES.map(h => h.id));
    if (overlayIds.has(stored.activeHack))    stored.activeOverlay = stored.activeHack;
    else if (themeIds.has(stored.activeHack)) stored.activeTheme   = stored.activeHack;
    await chrome.storage.local.set({
      activeOverlay: stored.activeOverlay,
      activeTheme:   stored.activeTheme,
      activeHack:    null,
    });
  }

  // Sync Active with the selection state on every popup open. If the
  // user has nothing picked, Active reflects off; if they have a pick
  // and Active was stale-off, it flips back on. Steps aside while a ">_"
  // override is active.
  await syncActiveToSelection();
  // Single render surface — picks up everything from storage including
  // the post-sync enabled flag, ">_" classes, etc.
  await renderFromStorage();
})();
