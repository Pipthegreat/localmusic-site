# DOM Perignon

A collection of UI hijinks. One Chrome extension, eight reality-bending overlays to enhance your browsing experience. Pick one from the popup and it stays active until you switch.

**Version 1.1.3** — competition release. Four "wild card" hijinks ship alongside the four classics; cull the ones that don't earn their slot.

---

## The collection

| # | Hijink | What it does |
|---|--------|--------------|
| 1 | **Ants** *(most popular)* | A colony of ~14 SVG ants crawls the page with momentum-based random walks, alternating-tripod gait, and antennae sway. |
| 2 | **Champagne Bubbles** *(house signature)* | Pale bubbles rise from below with realistic fizz physics — pre-populated at varied Y so the page is alive from frame one, jittered intervals so they never band. Click to pop. Corks ricochet across every ~28s. |
| 3 | **Site Logo Bounce-House** | Sniffs the current site's logo (apple-touch-icon → favicon → og:image → header img → /favicon.ico fallback) and bounces 8 small copies (sharper on low-res favicons). |
| 4 | **You Got This** | When you need a little laid-back inspiration. 60 soft affirmations drift across in Fraunces italic, painted in a desert/autumn palette (saffron, terracotta, sienna, mustard, sage, rosewood, adobe), each with a 1.5px black outline so they read on any background. |
| 5 | **Aquarium Mode** | The page becomes the back wall of a tank: blue-green wash, caustic shimmer, swaying kelp, rising bubble clusters, 4 fish species swimming through, cursor ripples. Every layer ~20% more transparent than v1.1.1 so the page reads through. |
| 6 | **Watchers** | Eyes appear quietly across the page at random tilts. Larger pupils, off-white sclera, a hint of dark red at the iris rim. They follow your cursor. They do not blink. |
| 7 | **DVD Bouncer** | If you're feeling nostalgic and uninspired. One small DVD-Video logo at 45° angles, color cycling on every wall bounce. Corner hits trigger a flash + counter. |

(Internal hijink IDs in `popup.js`, `manifest.json`, and the gallery iframes still use the original names: `quotes` = "You Got This", `dynamic-logo` = "Site Logo Bounce-House", `googly` = "Watchers". Renaming the IDs would invalidate stored selections; the display names are the user-facing surface.)

---

## Install (unpacked)

1. Unzip the folder somewhere stable (e.g. `Documents/dom-perignon-v1.1.3`).
2. Open Chrome and visit `chrome://extensions`.
3. Toggle **Developer mode** on (top-right).
4. Click **Load unpacked** and select the unzipped folder.
5. Pin the toolbar icon (puzzle-piece menu).

Chrome will warn that the extension can "read and change all your data on all websites." That is correct — the hijinks paint over the pages you open. There are no network calls and no telemetry.

---

## Use

Click the toolbar icon. The popup shows:
- **Active** master toggle — turns hijinks on/off without losing your selection
- **Select a hijink** — radio-list of the 8 hijinks (one at a time)

Changes apply to every open tab instantly. New tabs and reloads pick up the selection from `chrome.storage`.

---

## Architecture

```
dom-perignon/
├── manifest.json          MV3, host_permissions: <all_urls>
├── inject.js              Hijink router (load/teardown lifecycle)
├── popup.html             Ember-on-Slate themed picker
├── popup.js               Selection + broadcast to all tabs
├── icon-{16,48,128}.png   Champagne flute on slate
├── _make_icons.py         Regenerates the icons via PIL
├── hacks/
│   ├── ants.{js,css}
│   ├── dvd.{js,css}
│   ├── quotes.{js,css}
│   ├── dynamic-logo.{js,css}
│   ├── champagne.{js,css}
│   ├── googly.{js,css}
│   └── aquarium.{js,css}
└── README.md
```

(The `hacks/` folder name is the internal code identifier; the user-facing name is "hijinks." Keeping the folder name stable to avoid touching every JS path.)

Each hijink file registers itself on `window.__DOMPerignon.hacks[name]` as `{ init(root), teardown() }`. `inject.js` reads `chrome.storage.local.activeHack` and dispatches accordingly. Switching hijinks calls `teardown()` on the old one and `init()` on the new one — no reload required.

### Design language

Pulled from the sibling `Style/` project (Ember on Slate palette):
- **Type:** Fraunces (italic display), Inter (UI), JetBrains Mono (labels)
- **Palette:** slate-950 ground, ember-500 accent, ember-glow halo
- **Tokens:** authored in OKLCH per `Style/CLAUDE.md` §2.2

---

## Add a new hijink (when it survives competition)

1. Create `hacks/your-hijink.{js,css}` modeled on any existing pair.
2. The JS file must call `NS.hacks['your-hijink'] = { init, teardown }` at load time, where `NS = window.__DOMPerignon`. Use `NS.getCSSURL('hacks/your-hijink.css')` inside `init` to fetch your CSS.
3. Add `"hacks/your-hijink.js"` to the `js` array in `manifest.json` (before `inject.js`).
4. Add `{ id: 'your-hijink', name: '...', desc: '...' }` to the `HACKS` array in `popup.js`.

That's it — no other plumbing.

---

## Build & ship checklist (from the notebook)

- [x] Every hijink JS file declared in `manifest.json` content_scripts.js (before inject.js)
- [x] Every hijink ID in `popup.js` HACKS array matches its `NS.hacks[id]` registration
- [x] CSS files: balanced braces (verified `open == close`)
- [x] JS files parse cleanly (`node -e "new Function(fs.readFileSync(f))"`)
- [x] Manifest validates as JSON
- [x] Version in `manifest.json` matches version in `popup.html` footer ("v1.1.3")
- [x] Icons present in 16, 48, 128
- [x] Zip filename and folder-inside-zip include version suffix

---

## Known limits

- **Pages with strict CSP** may refuse to load the Google Fonts stylesheet for the You Got This hijink. The fallback is Georgia italic — still elegant, less distinctive.
- **chrome:// and Web Store pages** can't be touched by extensions; the hijink will simply not apply on those tabs.
- **Watchers** rescans every 1.5s to catch newly added elements (SPAs that mutate the DOM constantly).
