# DOM Perignon

A collection of UI hijinks. One Chrome extension, eight reality-bending overlays to enhance your browsing experience. Pick one from the popup and it stays active until you switch.

**Version 1.1.1** — competition release. Four "wild card" hijinks ship alongside the four classics; cull the ones that don't earn their slot.

---

## The collection

| # | Hijink | What it does |
|---|--------|--------------|
| 1 | **Ants** | A colony of ~14 SVG ants crawls the page with momentum-based random walks, alternating-tripod gait, and antennae sway. |
| 2 | **DVD Bouncer** | The classic. One DVD-Video logo at 45° angles, color cycling on every wall bounce. Corner hits trigger a celebratory flash + counter. |
| 3 | **Words of Encouragement** | Soft motivational quotes drift across the screen in Fraunces italic with an ember halo. 29-quote pool, 14–24s drift. |
| 4 | **Site Logo Bounce** | Sniffs the current site's logo (apple-touch-icon → favicon → og:image → header img → /favicon.ico fallback) and bounces 6 copies. |
| 5 | **Champagne Bubbles** | The house signature. Bubbles rise with realistic physics (smaller = faster), click to pop, corks ricochet across every ~28s. |
| 6 | **The Floor is Lava** | Page images and headings clone into fixed overlays, then fall to a glowing lava band at the bottom edge. Click to rescue. Originals tuck out of sight cleanly. |
| 7 | **Googly Eyes** | A faint colony of mouse-tracking eyes lands on images, buttons, and avatars at randomized positions. Each pupil computes its own angle to the cursor. |
| 8 | **Aquarium Mode** | The page becomes the back wall of a tank: blue-green wash, caustic shimmer, swaying kelp, rising bubble clusters, 4 fish species swimming through, cursor ripples. |

---

## Install (unpacked)

1. Unzip the folder somewhere stable (e.g. `Documents/dom-perignon-v1.1.1`).
2. Open Chrome and visit `chrome://extensions`.
3. Toggle **Developer mode** on (top-right).
4. Click **Load unpacked** and select the unzipped folder.
5. Pin the toolbar icon (puzzle-piece menu).

Chrome will warn that the extension can "read and change all your data on all websites." That is correct — the hijinks paint over the pages you open. There are no network calls and no telemetry.

---

## Use

Click the toolbar icon. The popup shows:
- **Active** master toggle — turns hijinks on/off without losing your selection
- **Select a hijink** — radio-list of the 8 hijinks (one at a time)

Changes apply to every open tab instantly. New tabs and reloads pick up the selection from `chrome.storage`.

---

## Architecture

```
dom-perignon/
├── manifest.json          MV3, host_permissions: <all_urls>
├── inject.js              Hijink router (load/teardown lifecycle)
├── popup.html             Ember-on-Slate themed picker
├── popup.js               Selection + broadcast to all tabs
├── icon-{16,48,128}.png   Champagne flute on slate
├── _make_icons.py         Regenerates the icons via PIL
├── hacks/
│   ├── ants.{js,css}
│   ├── dvd.{js,css}
│   ├── quotes.{js,css}
│   ├── dynamic-logo.{js,css}
│   ├── champagne.{js,css}
│   ├── lava.{js,css}
│   ├── googly.{js,css}
│   └── aquarium.{js,css}
└── README.md
```

(The `hacks/` folder name is the internal code identifier; the user-facing name is "hijinks." Keeping the folder name stable to avoid touching every JS path.)

Each hijink file registers itself on `window.__DOMPerignon.hacks[name]` as `{ init(root), teardown() }`. `inject.js` reads `chrome.storage.local.activeHack` and dispatches accordingly. Switching hijinks calls `teardown()` on the old one and `init()` on the new one — no reload required.

### Design language

Pulled from the sibling `Style/` project (Ember on Slate palette):
- **Type:** Fraunces (italic display), Inter (UI), JetBrains Mono (labels)
- **Palette:** slate-950 ground, ember-500 accent, ember-glow halo
- **Tokens:** authored in OKLCH per `Style/CLAUDE.md` §2.2

---

## Add a new hijink (when it survives competition)

1. Create `hacks/your-hijink.{js,css}` modeled on any existing pair.
2. The JS file must call `NS.hacks['your-hijink'] = { init, teardown }` at load time, where `NS = window.__DOMPerignon`. Use `NS.getCSSURL('hacks/your-hijink.css')` inside `init` to fetch your CSS.
3. Add `"hacks/your-hijink.js"` to the `js` array in `manifest.json` (before `inject.js`).
4. Add `{ id: 'your-hijink', name: '...', desc: '...' }` to the `HACKS` array in `popup.js`.

That's it — no other plumbing.

---

## Build & ship checklist (from the notebook)

- [x] Every hijink JS file declared in `manifest.json` content_scripts.js (before inject.js)
- [x] Every hijink ID in `popup.js` HACKS array matches its `NS.hacks[id]` registration
- [x] CSS files: balanced braces (verified `open == close`)
- [x] JS files parse cleanly (`node -e "new Function(fs.readFileSync(f))"`)
- [x] Manifest validates as JSON
- [x] Version in `manifest.json` matches version in `popup.html` footer ("v1.1.1")
- [x] Icons present in 16, 48, 128
- [x] Zip filename and folder-inside-zip include version suffix

---

## Known limits

- **Pages with strict CSP** may refuse to load the Google Fonts stylesheet for the Words of Encouragement hijink. The fallback is Georgia italic — still elegant, less distinctive.
- **chrome:// and Web Store pages** can't be touched by extensions; the hijink will simply not apply on those tabs.
- **The Floor is Lava** only clones elements visible in the viewport at activation time (max 28). Won't pick up new ones added after.
- **Googly Eyes** rescans every 1.5s to catch newly added elements (SPAs that mutate the DOM constantly).
