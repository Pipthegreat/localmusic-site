// DOM Perignon popup — hijink picker
//
// Persists selection to chrome.storage.local and broadcasts to every open
// tab so the hijink swaps in real-time without requiring a reload.

const HACKS = [
  { id: 'ants',         name: 'Ants',              desc: 'A colony marches across the page. On Adobe, they overrun the logos.' },
  { id: 'dvd',          name: 'DVD Bouncer',       desc: 'The classic. One logo, 45° bounces, prays for the corner.' },
  { id: 'quotes',       name: 'Words of Encouragement', desc: 'Soft motivational quotes drift across in Fraunces italic.' },
  { id: 'dynamic-logo', name: 'Site Logo Bounce',  desc: "Yanks the current site's logo and lets it loose to bounce." },
  { id: 'champagne',    name: 'Champagne Bubbles', desc: 'The signature hijink. Bubbles rise, corks pop, the page fizzes.', signature: true },
  { id: 'lava',         name: 'The Floor is Lava', desc: 'Page elements succumb to gravity. Click to rescue them back.' },
  { id: 'googly',       name: 'Googly Eyes',       desc: 'Every face on the internet now stares directly at your cursor.' },
  { id: 'aquarium',     name: 'Aquarium Mode',     desc: 'The page becomes the back wall of a tank. Bubbles, fish, kelp.' },
];

const toggle    = document.getElementById('enabledToggle');
const listEl    = document.getElementById('hackList');
const statusEl  = document.getElementById('status');

// Build the radio list
function renderList(activeHack, enabled) {
  listEl.innerHTML = HACKS.map(h => `
    <li>
      <label class="hack" data-id="${h.id}">
        <input type="radio" name="hack" value="${h.id}" ${h.id === activeHack ? 'checked' : ''} ${!enabled ? 'disabled' : ''}>
        <span class="radio"></span>
        <span class="meta">
          <div class="name">${h.name}</div>
          <div class="desc">${h.desc}</div>
          ${h.signature ? '<span class="badge">House signature</span>' : ''}
        </span>
      </label>
    </li>
  `).join('');

  // Dim the list visually when master toggle is off
  listEl.style.opacity = enabled ? '1' : '0.35';
  listEl.style.pointerEvents = enabled ? 'auto' : 'none';

  // Wire radio change → save + broadcast
  listEl.querySelectorAll('input[type=radio]').forEach(input => {
    input.addEventListener('change', async () => {
      const newHack = input.value;
      await chrome.storage.local.set({ activeHack: newHack });
      await broadcast(newHack);
      // re-render to update active styling
      const { enabled: e } = await chrome.storage.local.get({ enabled: true });
      renderList(newHack, e);
    });
  });
}

// Send the new hack to every tab. Some tabs may not have the content script
// (chrome://, certain restricted pages) — silently ignore those.
async function broadcast(hack) {
  try {
    const tabs = await chrome.tabs.query({});
    let succeeded = 0;
    for (const tab of tabs) {
      if (!tab.id) continue;
      try {
        await chrome.tabs.sendMessage(tab.id, { type: 'setHack', hack });
        succeeded++;
      } catch { /* tab without our content script */ }
    }
    if (hack === 'off') {
      statusEl.textContent = succeeded ? `Cleared on ${succeeded} tab${succeeded > 1 ? 's' : ''}.` : '';
    } else {
      statusEl.textContent = succeeded ? `Live on ${succeeded} tab${succeeded > 1 ? 's' : ''}.` : 'Reload tabs to apply.';
    }
  } catch (e) {
    statusEl.textContent = 'Unable to reach tabs.';
  }
}

// Master toggle handler
toggle.addEventListener('change', async () => {
  const enabled = toggle.checked;
  await chrome.storage.local.set({ enabled });
  const { activeHack } = await chrome.storage.local.get({ activeHack: 'off' });
  // If user just turned off, broadcast 'off' (don't lose their selection)
  // If user just turned on, broadcast their selection
  await broadcast(enabled ? activeHack : 'off');
  renderList(activeHack, enabled);
});

// Init
(async () => {
  const { activeHack, enabled } = await chrome.storage.local.get({
    activeHack: 'off',
    enabled: true,
  });
  toggle.checked = enabled;
  renderList(activeHack, enabled);
})();
