# DOM Perignon

Named after the innovator [Dom Pierre Pérignon](https://en.wikipedia.org/wiki/Dom_P%C3%A9rignon_%28monk%29). The **DOM** (Document Object Model) is the live tree of every web page's elements. DOM Perignon uses that for eight different perspectives. Pick one from the popup; it stays active until you switch.

**Version 1.1.3** - competition release. Four "wild card" hijinks ship alongside the four classics; cull the ones that don't earn their slot.

---

## The collection

| # | Hijink | What it does |
|---|--------|--------------|
| 1 | **Ants** *(most popular)* | A colony marches across the page. |
| 2 | **Champagne Bubbles** *(house signature)* | Bubbles rise, corks pop, the page fizzes. |
| 3 | **Logo Bounce House** | The site's logo, loose and bouncing - eight small copies. |
| 4 | **You Got This** | A little laid-back inspiration. Sixty affirmations in desert/autumn hues: saffron, terracotta, sienna, mustard, sage, rosewood, adobe. |
| 5 | **Gravity Well** | Page elements slowly fall and pile at the bottom. Click to rescue. |
| 6 | **Aquarium** | The page becomes the back wall of a tank. |
| 7 | **Watchers** | Eyes appear. They follow your cursor. They do not blink. |
| 8 | **DVD Bouncer** | If you're feeling nostalgic and uninspired. |

(Internal hijink IDs in `popup.js`, `manifest.json`, and the gallery iframes still use the original names: `quotes` = "You Got This", `dynamic-logo` = "Logo Bounce House", `googly` = "Watchers", `aquarium` = "Aquarium". Renaming the IDs would invalidate stored selections; the display names are the user-facing surface.)

---

## Install (unpacked)

1. Unzip the folder somewhere stable (e.g. `Documents/dom-perignon-v1.1.3`).
2. Open Chrome and visit `chrome://extensions`.
3. Toggle **Developer mode** on (top-right).
4. Click **Load unpacked** and select the unzipped folder.
5. Pin the toolbar icon (puzzle-piece menu).

Chrome will warn that the extension can "read and change all your data on all websites." That is correct - the hijinks paint over the pages you open. There are no network calls and no telemetry.

---

## Use

Click the toolbar icon. The popup shows:
- **Active** master toggle - turns hijinks on/off without losing your selection
- **Select a hijink** - radio-list of the 8 hijinks (one at a time)

Changes apply to every open tab instantly. New tabs and reloads pick up the selection from `chrome.storage`.

---

## Architecture

```
dom-perignon/
├── manifest.json          MV3, host_permissions: <all_urls>
├── inject.js              Hijink router (load/teardown lifecycle)
├── popup.html             Ember-on-Slate themed picker
├── popup.js               Selection + broadcast to all tabs
├── icon-{16,48,128}.png   Champagne flute on slate
├── _make_icons.py         Regenerates the icons via PIL
├── hacks/
│   ├── ants.{js,css}
│   ├── dvd.{js,css}
│   ├── quotes.{js,css}
│   ├── dynamic-logo.{js,css}
│   ├── champagne.{js,css}
│   ├── googly.{js,css}
│   └── aquarium.{js,css}
└── README.md
```

(The `hacks/` folder name is the internal code identifier; the user-facing name is "hijinks." Keeping the folder name stable to avoid touching every JS path.)

Each hijink file registers itself on `window.__DOMPerignon.hacks[name]` as `{ init(root), teardown() }`. `inject.js` reads `chrome.storage.local.activeHack` and dispatches accordingly. Switching hijinks calls `teardown()` on the old one and `init()` on the new one - no reload required.

### Design language

Pulled from the sibling `Style/` project (Ember on Slate palette):
- **Type:** Fraunces (italic display), Inter (UI), JetBrains Mono (labels)
- **Palette:** slate-950 ground, ember-500 accent, ember-glow halo
- **Tokens:** authored in OKLCH per `Style/CLAUDE.md` §2.2

---

## Add a new hijink (when it survives competition)

1. Create `hacks/your-hijink.{js,css}` modeled on any existing pair.
2. The JS file must call `NS.hacks['your-hijink'] = { init, teardown }` at load time, where `NS = window.__DOMPerignon`. Use `NS.getCSSURL('hacks/your-hijink.css')` inside `init` to fetch your CSS.
3. Add `"hacks/your-hijink.js"` to the `js` array in `manifest.json` (before `inject.js`).
4. Add `{ id: 'your-hijink', name: '...', desc: '...' }` to the `HACKS` array in `popup.js`.

That's it - no other plumbing.

---

## Build & ship checklist (from the notebook)

- [x] Every hijink JS file declared in `manifest.json` content_scripts.js (before inject.js)
- [x] Every hijink ID in `popup.js` HACKS array matches its `NS.hacks[id]` registration
- [x] CSS files: balanced braces (verified `open == close`)
- [x] JS files parse cleanly (`node -e "new Function(fs.readFileSync(f))"`)
- [x] Manifest validates as JSON
- [x] Version in `manifest.json` matches version in `popup.html` footer ("v1.1.3")
- [x] Icons present in 16, 48, 128
- [x] Zip filename and folder-inside-zip include version suffix

---

## Known limits

- **Pages with strict CSP** may refuse to load the Google Fonts stylesheet for the You Got This hijink. The fallback is Georgia italic - still elegant, less distinctive.
- **chrome:// and Web Store pages** can't be touched by extensions; the hijink will simply not apply on those tabs.
- **Watchers** rescans every 1.5s to catch newly added elements (SPAs that mutate the DOM constantly).
