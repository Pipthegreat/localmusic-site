# Adobe Home Odin Previewer

Preview Adobe Home with an Odin JSON override, from inside your own logged-in Chrome tab. Paste a URL, click Activate, reload — Adobe Home renders against the JSON at that URL instead of the production response.

## Install (local, unpacked)

1. Open `chrome://extensions` in Chrome.
2. Toggle **Developer mode** (top right).
3. Click **Load unpacked**.
4. Pick this folder (`Adobe Preview Tool Extension`).
5. Pin the extension to the toolbar so the badge is visible.

## Use

1. Open `https://www.adobe.com/home` and sign in as usual.
2. Click the extension icon. The popup appears with three numbered steps.
3. **01 — Paste an Odin URL.** Click **Fetch & save**. The popup will show the derived glob pattern and the body size.
4. **02 — Review the override.** Confirm the pattern, body, and source URL look right.
5. **03 — Activate and reload.** Click **Activate**. The badge on the extension icon turns ember and reads "ON". Click **Reload adobe.com** to apply.

To stop overriding, click **Deactivate** and reload the tab.

## How it works

- Content script runs at `document_start` on `adobe.com` in the isolated content-script world (`content_iso.js`).
- It reads the active override from `chrome.storage.local`, derives a regex from the glob, and posts the config via `window.postMessage` to a sibling MAIN-world content script (`content_main.js`).
- `content_main.js` wraps `window.fetch`. Every fetch URL is tested against the regex. Matches return a 200 with the stored body. Non-matches pass through to the live network.
- The override survives soft navigations within the SPA — the wrapped `fetch` stays in place for the life of the page. Hard reloads re-apply the wrapper from scratch.

The two-content-script design (one ISOLATED, one MAIN) is required: `chrome.storage` is only readable from the isolated world, and `window.fetch` is only wrappable in the page's own world. `postMessage` is the bridge.

## URL → pattern derivation

Paste any Odin URL; the extension uses the parent directory as the "surface family" and globs anything in that directory:

| Pasted URL | Derived pattern |
|---|---|
| `.../app-skeleton-apps-list/default-apps-v1.cfm.gql.arm1.json` | `**/app-skeleton-apps-list/**.json` |
| `.../genai-prompt-bar/gen-ai-prompt-bar-image-and-video.cfm.gql.json` | `**/genai-prompt-bar/**.json` |
| `.../appsPDP/PHSP.cfm.gql.json` | `**/appsPDP/**.json` |

The PDP case is intentionally broad — it'll swap all PDP bodies for the one you pasted. If you need finer control, edit the pattern in code.

## What it does NOT do

- **XHR interception.** Only `window.fetch` is wrapped in v0.2. Adobe Home's modern bundles are overwhelmingly fetch-based, but a surface that uses XHR will fall through to the live network. Verify with the console — every intercepted fetch logs `[Odin Previewer] INTERCEPT <url>` in orange.
- **Service worker bypass.** If Adobe caches an Odin response in a service worker, the SW handles it before our wrapper sees the request. Try a hard reload (Ctrl+Shift+R) if you're not seeing the override fire.
- **Multiple simultaneous overrides.** v0.2 holds exactly one (pattern, body) pair. To swap multiple surfaces at once, use the sibling Python tool (`../Adobe Preview Tool/scripts/preview.py`), which accepts repeated `--url-pattern`/`--override` pairs.

## Cohort note

Odin paths sometimes embed the cohort tier in the filename (e.g. `default-apps-v1-cc-pro.cfm.gql.ah.json`). The default pattern (`**/<family>/**.json`) intercepts both the cohort-suffixed URL and the generic one, so pasting the generic doc on a paid-cc-pro session swaps the cc-pro variant with the generic body. That's usually what you want for previewing.

## Visual system

The popup uses the Stle "Ember on Slate" palette — autumn fire on a cool slate spine, with a warm-tinted parchment canvas in light mode. OKLCH source values, system-font display serif (Iowan / Palatino / Cambria / Georgia), system-ui body, system monospace for the URL + regex metadata. Focus rings are first-class: 2px ember + 2px halo on every interactive element.

## Sibling project

For surface discovery (finding which Odin URL drives a given surface) and batch screenshot capture across cohorts, see `../Adobe Preview Tool/` and `../Miro of CCD/`. This extension is the day-to-day preview UX; the Python tool is the discovery / batch rig.
