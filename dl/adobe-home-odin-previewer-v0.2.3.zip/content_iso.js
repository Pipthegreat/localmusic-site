// Runs at document_start in the ISOLATED content-script world. Reads the
// active override from chrome.storage.local, converts the glob to a regex
// source string, and posts the config to the MAIN world via postMessage.
//
// We cannot wrap window.fetch from here — fetch in this world is a different
// function from the one the page sees. That's why we hand the config to
// content_main.js to install in the page world.

console.log(
  "%c[Preview Tool] content_iso loaded",
  "color: orange; font-weight: bold",
  { url: location.href },
);

(function () {
  function globToRegexSource(glob) {
    // Escape regex specials EXCEPT * (which we convert below).
    const escaped = glob.replace(/[.+?^${}()|[\]\\]/g, "\\$&");
    // Convert ** → .* and * → [^/]*. Do it via a placeholder so the second
    // replace doesn't see the asterisks the first one just inserted.
    const PLACEHOLDER = "\x00__DOUBLESTAR__\x00";
    const expanded = escaped
      .replace(/\*\*/g, PLACEHOLDER)
      .replace(/\*/g, "[^/]*")
      .replace(new RegExp(PLACEHOLDER, "g"), ".*");
    return "^" + expanded + "$";
  }

  chrome.storage.local.get(
    ["active", "pattern", "body", "sourceUrl"],
    (cfg) => {
      if (chrome.runtime.lastError) {
        console.error(
          "[Preview Tool] storage error:",
          chrome.runtime.lastError,
        );
        return;
      }
      console.log(
        "[Preview Tool] storage state:",
        {
          active: !!cfg.active,
          hasPattern: !!cfg.pattern,
          patternValue: cfg.pattern,
          bodyBytes: typeof cfg.body === "string" ? cfg.body.length : 0,
          sourceUrl: cfg.sourceUrl,
        },
      );
      if (!cfg.active) {
        console.log("[Preview Tool] active=false; not installing override.");
        return;
      }
      if (!cfg.pattern || typeof cfg.body !== "string") {
        console.warn(
          "[Preview Tool] active=true but missing pattern/body; nothing to install.",
        );
        return;
      }

      const reSource = globToRegexSource(cfg.pattern);
      console.log("[Preview Tool] posting config to MAIN world:", {
        pattern: cfg.pattern,
        reSource,
        bodyBytes: cfg.body.length,
        sourceUrl: cfg.sourceUrl,
      });

      window.postMessage(
        {
          __adobePreviewTool: "config",
          reSource,
          body: cfg.body,
          sourceUrl: cfg.sourceUrl || "",
        },
        window.location.origin,
      );
    },
  );
})();
