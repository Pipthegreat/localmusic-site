// Popup UI logic. Stores state in chrome.storage.local under these keys:
//   sourceUrl  — the Odin URL the user pasted
//   pattern    — glob derived from sourceUrl
//   body       — the fetched JSON body (string)
//   active     — boolean: is the override currently firing?
//
// Commit model: the toggle is the primary commit action. Flipping it ON
// will auto-fetch + save whatever's in the textarea (if it differs from
// what's already saved), then activate. "Fetch & save" remains as a
// secondary "preview the save without activating" option.

const $ = (id) => document.getElementById(id);

const els = {
  url: $("odin-url"),
  fetchBtn: $("fetch-btn"),
  clearBtn: $("clear-btn"),
  toggleBtn: $("toggle-btn"),
  toggleLabel: $("toggle-label"),
  reloadBtn: $("reload-btn"),
  statusPattern: $("status-pattern"),
  statusBody: $("status-body"),
  statusSource: $("status-source"),
  message: $("message"),
};

function setMessage(text, kind = "") {
  els.message.textContent = text;
  els.message.className = "message" + (kind ? " is-" + kind : "");
}

// Convert an Odin URL to a glob that matches the same surface family.
//   .../app-skeleton-apps-list/default-apps-v1.cfm.gql.arm1.json
//     → **/app-skeleton-apps-list/**.json
function deriveSurfacePattern(rawUrl) {
  let u;
  try {
    u = new URL(rawUrl.trim());
  } catch {
    return null;
  }
  const parts = u.pathname.split("/").filter(Boolean);
  if (parts.length < 2) return null;
  const family = parts[parts.length - 2];
  return `**/${family}/**.json`;
}

function renderStatus() {
  chrome.storage.local.get(
    ["active", "pattern", "body", "sourceUrl"],
    (cfg) => {
      const active = !!cfg.active;
      els.toggleBtn.setAttribute("aria-checked", active ? "true" : "false");
      els.toggleLabel.textContent = active ? "ON" : "OFF";

      els.statusPattern.textContent = cfg.pattern || "—";
      els.statusBody.textContent =
        typeof cfg.body === "string"
          ? `${(cfg.body.length / 1024).toFixed(1)} KB`
          : "—";
      els.statusSource.textContent = cfg.sourceUrl || "—";

      // Toggle is enabled if EITHER a URL is in the textarea OR something
      // is already saved. The fetch step is implied when needed.
      const hasTextareaUrl = !!els.url.value.trim();
      const hasSaved =
        cfg.pattern && typeof cfg.body === "string" && cfg.body.length > 0;
      els.toggleBtn.disabled = !active && !hasTextareaUrl && !hasSaved;
      els.toggleBtn.setAttribute(
        "aria-label",
        active ? "Deactivate override" : "Activate override",
      );

      if (cfg.sourceUrl && !els.url.value.trim()) {
        els.url.value = cfg.sourceUrl;
      }
    },
  );
}

// Internal: fetch a URL, validate JSON, save to chrome.storage.
// Returns true on success, false on error (and sets a message).
async function fetchAndSaveImpl(rawUrl) {
  const pattern = deriveSurfacePattern(rawUrl);
  if (!pattern) {
    setMessage("Couldn’t derive a pattern from that URL.", "error");
    return false;
  }
  try {
    const res = await fetch(rawUrl, { credentials: "omit" });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const body = await res.text();
    JSON.parse(body); // sanity-check valid JSON before storing
    await chrome.storage.local.set({
      sourceUrl: rawUrl,
      pattern,
      body,
    });
    return true;
  } catch (err) {
    setMessage(`Fetch failed: ${err.message || err}`, "error");
    return false;
  }
}

async function saveAndRefresh() {
  // Save the current textarea URL, then reload the adobe.com tab so the
  // override (if the toggle is ON) takes effect immediately. If the toggle
  // is OFF, this just saves and refreshes the live page — flipping the
  // toggle afterwards will show the new override on next reload.
  const raw = els.url.value.trim();
  if (!raw) {
    setMessage("Paste an Odin URL first.", "error");
    return;
  }
  els.fetchBtn.disabled = true;
  setMessage("Saving…");
  const ok = await fetchAndSaveImpl(raw);
  if (!ok) {
    els.fetchBtn.disabled = false;
    renderStatus();
    return;
  }
  const stored = await chrome.storage.local.get(["body"]);
  const kb = (stored.body.length / 1024).toFixed(1);
  renderStatus();

  // Saved — now refresh adobe.com.
  const tabs = await chrome.tabs.query({});
  const adobe = tabs.find(
    (t) => t.url && t.url.startsWith("https://www.adobe.com/"),
  );
  if (!adobe) {
    setMessage(`Saved ${kb} KB. No adobe.com tab open to refresh.`, "ok");
    els.fetchBtn.disabled = false;
    return;
  }
  await chrome.tabs.reload(adobe.id, { bypassCache: true });
  setMessage(`Saved ${kb} KB and refreshed adobe.com.`, "ok");
  els.fetchBtn.disabled = false;
}

async function clearAll() {
  await chrome.storage.local.clear();
  els.url.value = "";
  setMessage("Cleared.", "ok");
  renderStatus();
}

async function toggle() {
  if (els.toggleBtn.disabled) return;
  const cfg = await chrome.storage.local.get([
    "active",
    "sourceUrl",
    "body",
  ]);

  // Toggling OFF — just deactivate, never refetch.
  if (cfg.active) {
    await chrome.storage.local.set({ active: false });
    setMessage("Deactivated.", "ok");
    renderStatus();
    return;
  }

  // Toggling ON — auto-save the textarea URL if it's new, then activate.
  const raw = els.url.value.trim();
  const hasSaved = cfg.sourceUrl && typeof cfg.body === "string";
  const needsFetch = raw && raw !== cfg.sourceUrl;

  if (needsFetch) {
    els.toggleBtn.disabled = true;
    setMessage("Fetching…");
    const ok = await fetchAndSaveImpl(raw);
    if (!ok) {
      // fetchAndSaveImpl already set the error message; bail without activating.
      renderStatus();
      return;
    }
  } else if (!hasSaved) {
    setMessage("Paste an Odin URL first.", "error");
    renderStatus();
    return;
  }

  await chrome.storage.local.set({ active: true });
  setMessage("Activated. Reload the adobe.com tab.", "ok");
  renderStatus();
}

async function reloadAdobeTab() {
  const tabs = await chrome.tabs.query({});
  const adobe = tabs.find(
    (t) => t.url && t.url.startsWith("https://www.adobe.com/"),
  );
  if (!adobe) {
    setMessage("No adobe.com tab open.", "error");
    return;
  }
  await chrome.tabs.reload(adobe.id, { bypassCache: true });
  setMessage("Reloaded.", "ok");
}

els.fetchBtn.addEventListener("click", saveAndRefresh);
els.clearBtn.addEventListener("click", clearAll);
els.toggleBtn.addEventListener("click", toggle);
els.reloadBtn.addEventListener("click", reloadAdobeTab);

// Re-evaluate toggle enabled state as the user types (so the toggle
// "wakes up" the moment a URL is in the textarea, even before any save).
els.url.addEventListener("input", renderStatus);

renderStatus();
