# Adobe Home Odin Previewer — Install

This is an unpacked Chrome extension. Because it isn't published to the
Chrome Web Store, you have to install it as a developer extension. It's
two minutes once you know the steps.

## Step 1 — Extract this zip

If you're looking at this file inside the zip, you haven't extracted yet.
Right-click the zip → **Extract All…** (Windows) or double-click (macOS).
End up with a folder, not a zip. The folder needs to contain
`manifest.json` directly at its top level.

## Step 2 — Open chrome://extensions

Type `chrome://extensions` into your address bar and hit enter. (Or:
three-dot menu → Extensions → Manage Extensions.)

## Step 3 — Turn on Developer mode

Top right of the extensions page, there's a **Developer mode** toggle.
Flip it on. A new row of buttons appears: *Load unpacked*, *Pack extension*,
*Update*.

## Step 4 — Load unpacked

Click **Load unpacked**. A folder picker opens. Navigate to the folder
you extracted in Step 1 and click **Select Folder**.

You should now see "Adobe Home Odin Previewer" in your extensions list,
with the autumn "OP" monogram icon.

## Step 5 — Pin the icon

Click the puzzle-piece icon in your toolbar, find "Adobe Home Odin
Previewer", click the pin icon next to it. The OP monogram now sits in
your toolbar.

## Use

1. Go to `https://www.adobe.com/home` and sign in.
2. Click the OP icon. The popup opens.
3. Paste an Odin URL into the textarea. Click **Save & refresh** —
   that saves the URL and reloads adobe.com in one step.
4. The page now renders against your override. To stop, click the
   toggle (top right of the popup) to turn it OFF, then refresh.

## Troubleshooting

**"This extension may have been corrupted."** — You probably tried to
drag the .zip directly onto chrome://extensions. Chrome doesn't accept
zips. Extract first.

**"Manifest file is missing or unreadable."** — You pointed Chrome at
the wrong folder. The folder you select must contain `manifest.json`
directly (not in a subfolder).

**"Developer mode extensions" warning bar.** — Normal. This appears
because the extension isn't from the Web Store. You can dismiss it.

**Override doesn't fire.** — Open DevTools console on the adobe.com
tab, filter for "Preview Tool". You should see `[Preview Tool] INTERCEPT
<url>` in orange when an Odin call is caught. If you see "content_iso
loaded" but no INTERCEPT, your pattern doesn't match the URL the page
fetched — pasting a slightly different sibling URL usually fixes it.

**Updating to a new version.** — Replace the extracted folder with a
new extracted version, then click the refresh icon on the extension's
card at `chrome://extensions`. No need to remove and re-add.

## Note for branded Google Chrome

Recent versions of Google Chrome silently ignore `--load-extension` on
the command line. This means you cannot install via a script or
launcher; "Load unpacked" through the Developer mode UI is the only
working path. Sorry.
