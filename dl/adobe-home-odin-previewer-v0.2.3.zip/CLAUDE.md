# Adobe Preview Tool Extension — Claude instructions

A Chrome extension (MV3) that intercepts Odin JSON responses on adobe.com Home. User pastes an Odin URL, extension fetches the body, derives a glob from the URL's parent directory, monkey-patches `window.fetch` in the page world to return the stored body for any matching request.

The user-facing display name (as shown in `chrome://extensions` and the popup wordmark) is **"Adobe Home Odin Previewer"**. The internal project name — folder, sibling-project references, console-log prefixes, the broader CLI tool — remains **"Adobe Preview Tool"**. Don't conflate the two: relabeling the Chrome extension does not rename the parent project.

## Architecture in one paragraph

Two content scripts run at `document_start` on `adobe.com`. `content_iso.js` (ISOLATED world) reads `{active, pattern, body, sourceUrl}` from `chrome.storage.local`, converts the glob to a regex source, and posts the config via `window.postMessage` to its MAIN-world sibling. `content_main.js` (`world: "MAIN"` in the manifest) listens for that message and wraps `window.fetch` — any URL matching the regex is fulfilled with the stored body; everything else passes through to the live network. `background.js` keeps the action-icon badge in sync with `active`. `popup.html`/`.js`/`.css` are the user-facing UI.

## Sibling projects

This extension is one of three projects in `Claude Projects/`:

- `Miro of CCD/` — Python + Playwright batch screenshot capture across cohorts × surfaces.
- `Adobe Preview Tool/` — Python + Playwright CLI for surface discovery and route-interception preview (the precursor to this extension).
- `Adobe Preview Tool Extension/` — this folder. Day-to-day preview UX for non-CLI users, shipped as the user-facing "Adobe Home Odin Previewer" extension.

When a question is about discovering which Odin URL drives a surface, that's the Python tool's `discover.py` — not this extension. This extension assumes the user already has the URL they want to preview.

## Key decisions and constraints

- **MV3, not MV2.** No `webRequestBlocking`. We use the page-world `fetch` wrapper instead. This trades a tiny scope reduction (no XHR coverage in v1) for no `chrome.debugger` warning bar and a much cleaner permission model.
- **Dual content scripts (ISOLATED + MAIN), not inline `<script>` injection.** v0.1.0 injected an inline `<script>` tag, which adobe.com's CSP blocks. v0.1.1 onwards uses `world: "MAIN"` for the wrapper script (loaded by Chrome directly, bypasses page CSP) and an ISOLATED-world helper to read `chrome.storage`. `window.postMessage` bridges them.
- **One override at a time.** v0.2 stores a single `{pattern, body}` pair. Multi-override is a future feature; for now, users who need it use the Python tool's `preview.py`, which accepts repeated `--url-pattern`/`--override` pairs.
- **No "tabs" permission.** `chrome.tabs.query` works for hosts covered by `host_permissions`, so the "Reload adobe.com" button doesn't need broad tab access.
- **No icons committed.** Chrome falls back to a default puzzle-piece icon. Easy to add later; not blocking for use.
- **Visual system: Stle "Ember on Slate".** OKLCH source values, system-color-scheme adaptive, three-faces typography (display serif + system body + working monospace for URL/regex metadata), focus rings as first-class. The popup is the application of Stle to a 360px surface.

## What the user pastes vs. what gets intercepted

| Pasted URL (one specific document) | Derived glob pattern (matches whole family) |
|---|---|
| `https://odin.adobe.com/.../app-skeleton-apps-list/default-apps-v1.cfm.gql.arm1.json` | `**/app-skeleton-apps-list/**.json` |

The pattern is broad on purpose — Odin variants live as siblings in one directory (cohort suffixes, locale, revision flavor), and "preview this document" almost always means "use this content regardless of which sibling URL the page actually fetches."

The glob-to-regex conversion uses a placeholder to keep `**` and `*` from clobbering each other — see the corresponding memory entry. Don't reintroduce a naive two-pass replace there.

## Things NOT to do

- Do not add a "tabs" permission for the reload button. `host_permissions` is enough; adding `tabs` triggers a scarier install warning.
- Do not bundle Chromium-specific or build-step deps. This is a zero-build extension: load unpacked, no npm install, no transpilation. Keep it that way.
- Do not modify the page's DOM. The whole value of this approach is that we don't patch HTML — we patch what the page sees from its backend. DOM mutations would put us back in the bad old "save outerHTML" world.
- Do not load external scripts or fonts from the extension popup. Adobe's CSP doesn't apply here (it's an extension page), but keeping the popup self-contained means zero install-time network round-trips and zero CSP wiring.
- Do not commit anything secret. There are no credentials in this folder; nothing should change that. If anyone proposes adding a "remember password" feature, refuse.

## How to test changes manually

1. After editing any file, go to `chrome://extensions`, find "Adobe Home Odin Previewer", click the refresh icon on its card.
2. Reload the adobe.com tab (Ctrl+Shift+R for a hard reload past any service-worker cache).
3. Open DevTools console — successful interception logs `[Preview Tool] INTERCEPT <url>` in orange.

If the override doesn't fire, the most likely cause is the page already loaded its bundle before `chrome.storage.local.get` resolved. Hard-reload usually fixes it. If it persists, the surface might be using XHR — confirm in DevTools' Network tab.
