// Background service worker.
// Only job: keep the extension-icon badge in sync with `active` state in
// storage, so the user can see at a glance whether overrides are firing.
//
// Badge color is the sRGB approximation of Stle ember.500 = oklch(62% 0.17 40).
// chrome.action APIs do not accept oklch() — we ship the hex fallback.

const BADGE_ON = { text: "ON", color: "#d96c2a" };
const BADGE_OFF = { text: "", color: "#000000" };

function syncBadge() {
  chrome.storage.local.get(["active"], (cfg) => {
    const b = cfg.active ? BADGE_ON : BADGE_OFF;
    chrome.action.setBadgeText({ text: b.text });
    chrome.action.setBadgeBackgroundColor({ color: b.color });
  });
}

chrome.runtime.onInstalled.addListener(syncBadge);
chrome.runtime.onStartup.addListener(syncBadge);

chrome.storage.onChanged.addListener((changes, area) => {
  if (
    area === "local" &&
    Object.prototype.hasOwnProperty.call(changes, "active")
  ) {
    syncBadge();
  }
});
