// Runs at document_start in the MAIN world (the page's own JavaScript
// context). Cannot see chrome.* APIs. Its only job is to wait for a config
// message from the ISOLATED-world content script, then wrap window.fetch.
//
// We register the listener synchronously here so it is in place before
// content_iso.js (which does an async chrome.storage.get) gets a chance to
// post.

console.log(
  "%c[Preview Tool] content_main loaded (MAIN world)",
  "color: orange; font-weight: bold",
  { url: location.href },
);

(function () {
  let installed = false;

  function install(reSource, body, sourceUrl) {
    if (installed) {
      console.warn("[Preview Tool] wrapper already installed; ignoring.");
      return;
    }
    installed = true;

    let RE;
    try {
      RE = new RegExp(reSource);
    } catch (e) {
      console.error("[Preview Tool] invalid regex:", reSource, e);
      return;
    }

    const origFetch = window.fetch.bind(window);
    window.fetch = function (input, init) {
      const url =
        typeof input === "string"
          ? input
          : input && input.url
          ? input.url
          : "";
      if (url && RE.test(url)) {
        console.log(
          "%c[Preview Tool] INTERCEPT %s",
          "color: orange; font-weight: bold",
          url,
        );
        return Promise.resolve(
          new Response(body, {
            status: 200,
            headers: { "content-type": "application/json" },
          }),
        );
      }
      return origFetch(input, init);
    };

    // Mark on window so DevTools console can verify the wrapper is in place.
    window.__adobePreviewToolActive = true;
    window.__adobePreviewToolPattern = RE.source;
    window.__adobePreviewToolSource = sourceUrl || "";

    console.log(
      "%c[Preview Tool] override active",
      "color: orange; font-weight: bold",
      { pattern: RE.source, sourceUrl },
    );
  }

  window.addEventListener("message", (event) => {
    // Only accept messages from our own window — ignore frame postMessages.
    if (event.source !== window) return;
    const data = event.data;
    if (!data || data.__adobePreviewTool !== "config") return;
    console.log("[Preview Tool] main received config message");
    install(data.reSource, data.body, data.sourceUrl);
  });
})();
